var cacheName = 'pwaTeste+-v1.2';

self.addEventListener('install', event => {

  self.skipWaiting();

  event.waitUntil(
    caches.open(cacheName)
      .then(cache => cache.addAll([


        './index.html',

        "./assets/vendor/bootstrap/css/bootstrap.min.css",
        "./assets/vendor/bootstrap-icons/bootstrap-icons.css",
        "./assets/vendor/aos/aos.css",
        "./assets/vendor/glightbox/css/glightbox.min.css",
  
        "./assets/vendor/swiper/swiper-bundle.min.css" ,

        "./assets/img/favicon.png",
        "./assets/img/apple-touch-icon.png",
        

        "./assets/css/main.css",

        "./assets/vendor/bootstrap/js/bootstrap.bundle.min.js",
        "./assets/vendor/aos/aos.js",
        "./assets/vendor/glightbox/js/glightbox.min.js",
        "./assets/vendor/purecounter/purecounter_vanilla.js",
        "./assets/vendor/swiper/swiper-bundle.min.js",
        "./assets/vendor/php-email-form/validate.js",

        './assets/img/background.png',
        './assets/img/favicon.png',
        './assets/img/logo.png',
        "./assets/img/icons/128.png",
        "./assets/img/icons/144.png",
        "./assets/img/icons/152.png",
        "./assets/img/icons/167.png",
        "./assets/img/icons/180.png",
       
      ]))
  );
});

self.addEventListener('message', function (event) {
  if (event.data.action === 'skipWaiting') {
    self.skipWaiting();
  }
});

self.addEventListener('fetch', function (event) {
  //Atualizacao internet
  event.respondWith(async function () {
     try {
       return await fetch(event.request);
     } catch (err) {
       return caches.match(event.request);
     }
   }());

  //Atualizacao cache
  /*event.respondWith(
    caches.match(event.request)
      .then(function (response) {
        if (response) {
          return response;
        }
        return fetch(event.request);
      })
  );*/

});